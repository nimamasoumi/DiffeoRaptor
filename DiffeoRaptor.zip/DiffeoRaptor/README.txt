This is a free C++ library of "DiffeoRaptor: Diffeomorphic Multimodal Image Registration using RaPTOR"

The implementation includes pairwise image matching and other tools for 3D medical images. This code is only for research purpose, and we request you to cite our research paper if you use it.
